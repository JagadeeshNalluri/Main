package com.dineshonjava.service;


import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;


import com.dineshonjava.dao.ContactDao;
import com.dineshonjava.model.Contact;


 
@Service("contactService")
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class ContactServiceImpl implements ContactService {


    @Autowired
    private ContactDao contactDao;
    
    @Transactional(propagation = Propagation.REQUIRED, readOnly = false)
    public void addContact(Contact contact) {
        contactDao.addContact(contact);
    }
    
    public List<Contact> listContactss() {
        return contactDao.listContactss();
    }


    public Contact getContact(int id) {
        return contactDao.getContact(id);
    }
    
    public void deleteContact(Contact contact) {
        contactDao.deleteContact(contact);
    }


}
 









