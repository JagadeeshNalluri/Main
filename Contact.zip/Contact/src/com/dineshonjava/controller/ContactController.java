package com.dineshonjava.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;


import com.dineshonjava.bean.ContactBean;

import com.dineshonjava.model.Contact;
import com.dineshonjava.model.Contact;
import com.dineshonjava.service.ContactService;


 
@Controller
public class ContactController {
    
    @Autowired
    private ContactService contactService;
    
    @RequestMapping(value = "/save", method = RequestMethod.POST)
    public ModelAndView saveContact(@ModelAttribute("command") ContactBean contactBean, BindingResult result) {
    Contact contact = prepareModel(contactBean);
        contactService.addContact(contact);
        return new ModelAndView("redirect:/add.html");
    }


    @RequestMapping(value="/contacts", method = RequestMethod.GET)
    public ModelAndView listContacts() {
        Map<String, Object> model = new HashMap<String, Object>();
        model.put("contacts",  prepareListofBean(contactService.listContactss()));
        return new ModelAndView("contactsList", model);
    }


    @RequestMapping(value = "/add", method = RequestMethod.GET)
    public ModelAndView addContact(@ModelAttribute("command")  ContactBean contactBean,
            BindingResult result) {
        Map<String, Object> model = new HashMap<String, Object>();
        model.put("contacts",  prepareListofBean(contactService.listContactss()));
        return new ModelAndView("addContact", model);
    }
    
    @RequestMapping(value = "/index", method = RequestMethod.GET)
    public ModelAndView welcome() {
        return new ModelAndView("index");
    }
    
 @RequestMapping(value = "/delete", method = RequestMethod.GET)
    public ModelAndView editContact(@ModelAttribute("command")  ContactBean contactBean,
            BindingResult result) {
        contactService.deleteContact(prepareModel(contactBean));
        Map<String, Object> model = new HashMap<String, Object>();
        model.put("contact", null);
        model.put("contacts",  prepareListofBean(contactService.listContactss()));
        return new ModelAndView("addContact", model);
    }
    
    @RequestMapping(value = "/edit", method = RequestMethod.GET)
    public ModelAndView deleteContact(@ModelAttribute("command")  ContactBean contactBean,
            BindingResult result) {
        Map<String, Object> model = new HashMap<String, Object>();
        model.put("contact", prepareContactBean(contactService.getContact(contactBean.getId())));
        model.put("contacts",  prepareListofBean(contactService.listContactss()));
        return new ModelAndView("addContact", model); 
    }
    
   private Contact prepareModel(ContactBean contactBean){
		Contact contact = new Contact();
		contact.setId(contactBean.getId());
		contact.setName(contactBean.getName());
		contact.setEmail(contactBean.getEmail());
		contact.setContactno(contactBean.getContactno());
		contact.setTime(contactBean.getTime());
		
	contactBean.setId(null);
		return contact;
	}
    
    
/*    private Contact prepareModel(ContactBean contactBean){
        Contact contact = new Contact();
        contact.setId(contactBean.getId());
        contact.setName(contactBean.getName());
        contact.setEmail(contactBean.getEmail());
        contact.setContactno(contactBean.getContactno());
        contact.setTime(contactBean.getTime());
        contactBean.setId((Integer) null);
        return contact;
    }
    */
    
    private List<ContactBean> prepareListofBean(List<Contact> contacts){
        List<ContactBean> beans = null;
        if(contacts != null && !contacts.isEmpty()){
            beans = new ArrayList<ContactBean>();
            ContactBean bean = null;
            for(Contact contact : contacts){
                bean = new ContactBean();
                bean.setId(contact.getId());
                bean.setName(contact.getName());
                bean.setEmail(contact.getEmail());
                bean.setContactno(contact.getContactno());
                bean.setTime(contact.getTime());
                beans.add(bean);
            }
        }
        return beans;
    }
    
    private ContactBean prepareContactBean(Contact contact){
        ContactBean bean = new ContactBean();
        bean = new ContactBean();
        bean.setId(contact.getId());
        bean.setName(contact.getName());
        bean.setEmail(contact.getEmail());
        bean.setContactno(contact.getContactno());
        bean.setTime(contact.getTime());
    
        
        return bean;
    }
}








